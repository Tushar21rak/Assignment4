import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <div>
                    <img src="https://myams.org/wp-content/uploads/2013/11/Blog-graphic-from-Istock.jpg" alt="Blog Post" height="100px" width="100%"/>
            </div>
        );
    }
}

export default Header;