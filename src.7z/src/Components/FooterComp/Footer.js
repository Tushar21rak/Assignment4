import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div className="Footer-style">
                <h6>Copyright © 2020 Tushar Rakholiya.</h6>
            </div>
        );
    }
}

export default Footer;